var APP_DATA = {
  "scenes": [
    {
      "id": "0-0001-1",
      "name": "0001 (1)",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": -1.5598462093209395,
        "pitch": 0.1035121124910372,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -2.5697189877424798,
          "pitch": 0.41994516349622657,
          "rotation": 0,
          "target": "8-0001-9"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-0001-2",
      "name": "0001 (2)",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": -1.4636089110594739,
        "pitch": 0.02911278163810671,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -1.7487614522192416,
          "pitch": 0.3623785622338147,
          "rotation": 0,
          "target": "5-0001-6"
        },
        {
          "yaw": 1.289991336899444,
          "pitch": 0.7578096386605626,
          "rotation": 0,
          "target": "4-0001-5"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "2-0001-3",
      "name": "0001 (3)",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": -1.760340580698939,
        "pitch": -0.07763408436828456,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -1.7249663237929944,
          "pitch": 0.2019804828831191,
          "rotation": 6.283185307179586,
          "target": "4-0001-5"
        },
        {
          "yaw": -0.7690321804809344,
          "pitch": 0.2792418992764496,
          "rotation": 0.7853981633974483,
          "target": "3-0001-4"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -1.0980115597647497,
          "pitch": -0.45562073581453433,
          "title": "Casa Camila &amp; Bruno",
          "text": "<div>Vista da entrada principal e entrada da garagem.</div>"
        }
      ]
    },
    {
      "id": "3-0001-4",
      "name": "0001 (4)",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": -1.5919253087414056,
        "pitch": -0.012939014061384313,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -2.6116830148316375,
          "pitch": 0.19823670569064333,
          "rotation": 5.497787143782138,
          "target": "2-0001-3"
        },
        {
          "yaw": -1.8751985802708901,
          "pitch": 0.2509443520391734,
          "rotation": 0.7853981633974483,
          "target": "4-0001-5"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "4-0001-5",
      "name": "0001 (5)",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": -1.4741914173913742,
        "pitch": -0.1418791904405836,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -1.9380509371010586,
          "pitch": 0.606807144992791,
          "rotation": 0,
          "target": "1-0001-2"
        },
        {
          "yaw": 2.558710376618256,
          "pitch": 0.1616160555031101,
          "rotation": 0,
          "target": "2-0001-3"
        },
        {
          "yaw": 1.3491966800149218,
          "pitch": 0.23772919109928026,
          "rotation": 5.497787143782138,
          "target": "3-0001-4"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -1.0923586967751717,
          "pitch": -0.37174453491876136,
          "title": "Casa Camila &amp; Bruno",
          "text": "Entrada principal protegida pelo balanço do pavimento superior"
        }
      ]
    },
    {
      "id": "5-0001-6",
      "name": "0001 (6)",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": -1.5819005901725127,
        "pitch": 0.05822556327620987,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -1.4396713178672975,
          "pitch": 0.4450550139142102,
          "rotation": 6.283185307179586,
          "target": "6-0001-7"
        },
        {
          "yaw": 1.2953771210812874,
          "pitch": 0.7429227275951487,
          "rotation": 0,
          "target": "1-0001-2"
        },
        {
          "yaw": -2.2154437836016143,
          "pitch": 0.5481281422603246,
          "rotation": 0,
          "target": "10-0001-11"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -0.9108642456962652,
          "pitch": -0.3582008808906032,
          "title": "Casa Camila &amp; Bruno",
          "text": "A partir do hall de entrada o convidado ou morador pode se deslocar para dois ambientes, a sala ou o espaço externo de lazer."
        },
        {
          "yaw": 0.31423295840289,
          "pitch": -0.11042082915706253,
          "title": "Casa Camila &amp; Bruno",
          "text": "O espelho d'água é formado a partir de uma das bordas da piscina, proporcionando um micro clima e um cenário diferenciado no hall da casa."
        }
      ]
    },
    {
      "id": "6-0001-7",
      "name": "0001 (7)",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": -0.9769543627731423,
        "pitch": 0.038817042184126294,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -1.376572544900931,
          "pitch": 0.20562625073140595,
          "rotation": 0,
          "target": "7-0001-8"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "7-0001-8",
      "name": "0001 (8)",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": -0.08586055945315962,
        "pitch": 0.14556390819052467,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 1.1647788790884661,
          "pitch": 0.47316931340312784,
          "rotation": 0.7853981633974483,
          "target": "8-0001-9"
        },
        {
          "yaw": -0.8718256168567304,
          "pitch": 0.479817137914031,
          "rotation": 0,
          "target": "9-0001-10"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 2.0533406793132265,
          "pitch": -0.38671094936075967,
          "title": "Casa Camila &amp; Bruno",
          "text": "Área de lazer da casa, com piscina, churrasqueira, fogão a lenha e pátio."
        },
        {
          "yaw": -1.6867353456313872,
          "pitch": 0.389388368368774,
          "title": "Casa Camila &amp; Bruno",
          "text": "Fogão a lenha."
        },
        {
          "yaw": -0.08924655250054592,
          "pitch": -0.31585195105503416,
          "title": "Casa Camila &amp; Bruno",
          "text": "Churrasqueira."
        }
      ]
    },
    {
      "id": "8-0001-9",
      "name": "0001 (9)",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": -1.1668772414200212,
        "pitch": 0.0032347535153380846,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -0.6894097940006567,
          "pitch": 0.7233765413716426,
          "rotation": 0,
          "target": "7-0001-8"
        },
        {
          "yaw": -2.810071926832217,
          "pitch": 0.20903998892653775,
          "rotation": 0.7853981633974483,
          "target": "15-0001-16"
        },
        {
          "yaw": 0.42140888042070124,
          "pitch": 0.04870343772389418,
          "rotation": 0,
          "target": "0-0001-1"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -1.8463050590727033,
          "pitch": 0.07387973833892403,
          "title": "Casa Camila &amp; Bruno",
          "text": "Piscina com praia e borda infinita, em estilo raia."
        }
      ]
    },
    {
      "id": "9-0001-10",
      "name": "0001 (10)",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": -1.401455655932308,
        "pitch": 0.09704260546034504,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -2.830516535143797,
          "pitch": 0.42277229822603957,
          "rotation": 0,
          "target": "7-0001-8"
        },
        {
          "yaw": -1.2281210146364518,
          "pitch": 0.5409155075762442,
          "rotation": 0,
          "target": "10-0001-11"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -0.49430409545239584,
          "pitch": -0.039874793861166324,
          "title": "Casa Camila &amp; Bruno",
          "text": "Espaço com infraestrutura preparada para receber um aquario."
        },
        {
          "yaw": -0.4902208973551936,
          "pitch": 0.1735376718060735,
          "title": "Casa Camila &amp; Bruno",
          "text": "Corredor que leva em direção ao lavabo interno e sala e home cinema."
        }
      ]
    },
    {
      "id": "10-0001-11",
      "name": "0001 (11)",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": -1.6119906551399659,
        "pitch": 0.06792982382224366,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -1.899884260139146,
          "pitch": -0.1924028714769399,
          "rotation": 0.7853981633974483,
          "target": "16-0001-17"
        },
        {
          "yaw": 0.9728152961443932,
          "pitch": 0.6119679539667526,
          "rotation": 0.7853981633974483,
          "target": "5-0001-6"
        },
        {
          "yaw": -1.4380815581676067,
          "pitch": 0.4020591445680619,
          "rotation": 0,
          "target": "9-0001-10"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -1.2860641120433947,
          "pitch": -0.40479961646021323,
          "title": "Casa Camila &amp; Bruno",
          "text": "Sala com pé direito duplo."
        },
        {
          "yaw": -3.0491699329460378,
          "pitch": -0.1042352915070488,
          "title": "Casa Camila &amp; Bruno",
          "text": "Hall de distribuição para acesso a área de serviço, apoio&nbsp; e garagem."
        }
      ]
    },
    {
      "id": "11-0001-12",
      "name": "0001 (12)",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": -1.1307882545719945,
        "pitch": 0.3461186261419087,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 3.114936766398978,
          "pitch": 0.5389889221025541,
          "rotation": 0,
          "target": "16-0001-17"
        },
        {
          "yaw": -0.47287229177397805,
          "pitch": 0.15839552978475524,
          "rotation": 4.71238898038469,
          "target": "12-0001-13"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -1.5401321138973643,
          "pitch": -0.021672931363040604,
          "title": "Casa Camila &amp; Bruno",
          "text": "Brise em madeira para proteger da radiação oeste."
        }
      ]
    },
    {
      "id": "12-0001-13",
      "name": "0001 (13)",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": -1.1849217348440568,
        "pitch": 0.2814235558350049,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -2.4881181683908284,
          "pitch": 0.08072361882680923,
          "rotation": 1.5707963267948966,
          "target": "11-0001-12"
        },
        {
          "yaw": 0.195161964767534,
          "pitch": 0.8724083665909284,
          "rotation": 0,
          "target": "13-0001-14"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "13-0001-14",
      "name": "0001 (14)",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": -1.5323527468622142,
        "pitch": -0.006030584442449083,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 0.3314429356376625,
          "pitch": 0.8044404801202774,
          "rotation": 0,
          "target": "12-0001-13"
        },
        {
          "yaw": -1.5589168634257682,
          "pitch": 0.3650992215831046,
          "rotation": 0,
          "target": "14-0001-15"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -2.2204145740579335,
          "pitch": -0.1772416029935382,
          "title": "Casa Camila &amp; Bruno",
          "text": "Acesso banheiro suíte."
        },
        {
          "yaw": -1.099270271727562,
          "pitch": -0.25295576304378464,
          "title": "Casa Camila &amp; Bruno",
          "text": "Acesso closet Camila."
        }
      ]
    },
    {
      "id": "14-0001-15",
      "name": "0001 (15)",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": -2.1458404769501893,
        "pitch": 0.1257152094279892,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 2.7915887212821744,
          "pitch": 0.28727471359227685,
          "rotation": 0,
          "target": "13-0001-14"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -2.5828772233542665,
          "pitch": -0.331373802582549,
          "title": "Casa Camila &amp; Bruno",
          "text": "Infra para suíte do casal."
        },
        {
          "yaw": 2.5135483323882504,
          "pitch": -0.17218722913899143,
          "title": "Casa Camila &amp; Bruno",
          "text": "Vista jardim de inverno."
        }
      ]
    },
    {
      "id": "15-0001-16",
      "name": "0001 (16)",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": -1.8951936595712873,
        "pitch": -0.10027735897569912,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -1.0723889420264374,
          "pitch": 0.12320385825354307,
          "rotation": 5.497787143782138,
          "target": "8-0001-9"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "16-0001-17",
      "name": "0001 (17)",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": -1.5799548191683694,
        "pitch": 0.1682071827979339,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -0.8550772591999163,
          "pitch": 0.7902481908844621,
          "rotation": 0,
          "target": "10-0001-11"
        },
        {
          "yaw": -0.19468829103875507,
          "pitch": 0.2826246992807686,
          "rotation": 5.497787143782138,
          "target": "11-0001-12"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -2.727094354703116,
          "pitch": 0.10023001257084196,
          "title": "Casa Camila &amp; Bruno",
          "text": "Dormitório B"
        },
        {
          "yaw": 2.7332057136340255,
          "pitch": 0.09650354695435581,
          "title": "Casa Camila &amp; Bruno",
          "text": "Acesso dormitório A&nbsp; e banheiro social."
        },
        {
          "yaw": -0.36092607687234235,
          "pitch": 0.024775051535153025,
          "title": "Casa Camila &amp; Bruno",
          "text": "Home office e espaço de estudos."
        }
      ]
    }
  ],
  "name": "Casa_Camila_Bruno_03",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": false,
    "fullscreenButton": true,
    "viewControlButtons": true
  }
};
